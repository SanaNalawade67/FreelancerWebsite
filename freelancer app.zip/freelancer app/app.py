from flask import Flask, render_template, request, redirect, url_for, session
from flask_bcrypt import Bcrypt
import sqlite3
import os

app = Flask(__name__, template_folder="templates")
app.secret_key = "your_secret_key"  # Secret key for session management
bcrypt = Bcrypt(app)
app.config["UPLOAD_FOLDER"] = "static/uploads"

# Ensure upload folder exists
if not os.path.exists(app.config["UPLOAD_FOLDER"]):
    os.makedirs(app.config["UPLOAD_FOLDER"])

# Function to initialize the database
def init_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            posted_by TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            applicant TEXT NOT NULL,
            message TEXT NOT NULL,
            status TEXT DEFAULT 'Pending',
            FOREIGN KEY (job_id) REFERENCES jobs (id)
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS profiles (
            user_id INTEGER PRIMARY KEY,
            name TEXT,
            bio TEXT,
            skills TEXT,
            experience TEXT,
            profile_picture TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        try:
            conn = sqlite3.connect('users.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            return "Error: Username already exists. <a href='/signup'>Try again</a>"

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()

        if user and bcrypt.check_password_hash(user[0], password):
            session['username'] = username  # Store username in session
            return redirect(url_for('dashboard'))
        return "Invalid credentials. <a href='/login'>Try again</a>"

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    username = session['username']

    # Open the database connection
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Fetch job listings
    cursor.execute("SELECT id, title, description, posted_by FROM jobs")
    jobs = cursor.fetchall()  # Ensure 'id' is the first column

    # Fetch applications
    cursor.execute("SELECT id, job_id, applicant, message, status FROM applications")
    applications = cursor.fetchall()

    # Close the connection *AFTER* fetching the data
    conn.close()

    return render_template('dashboard.html', username=username,jobs=jobs , applications=applications)


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    username = session['username']
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
    user_id = cursor.fetchone()[0]

    cursor.execute("SELECT name, bio, skills, experience, profile_picture FROM profiles WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()

    if not user:
        cursor.execute("INSERT INTO profiles (user_id, name, bio, skills, experience, profile_picture) VALUES (?, '', '', '', '', '')", (user_id,))
        conn.commit()
        user = ("", "", "", "", "")

    conn.close()
    return render_template("profile.html", user={"name": user[0], "bio": user[1], "skills": user[2], "experience": user[3], "profile_picture": user[4] or "static/default.png"})

@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    username = session['username']
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
    user_id = cursor.fetchone()[0]
    
    name = request.form["name"]
    bio = request.form["bio"]
    skills = request.form["skills"]
    experience = request.form["experience"]
    profile_picture = None

    if "profile_picture" in request.files:
        file = request.files["profile_picture"]
        if file.filename != "":
            profile_picture = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(profile_picture)

    if profile_picture:
        cursor.execute("UPDATE profiles SET name=?, bio=?, skills=?, experience=?, profile_picture=? WHERE user_id=?", 
                       (name, bio, skills, experience, profile_picture, user_id))
    else:
        cursor.execute("UPDATE profiles SET name=?, bio=?, skills=?, experience=? WHERE user_id=?", 
                       (name, bio, skills, experience, user_id))

    conn.commit()
    conn.close()
    return redirect(url_for("profile"))

@app.route('/apply/<int:job_id>', methods=['GET', 'POST'])
def apply(job_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        applicant = session['username']
        message = request.form.get('message')

        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO applications (job_id, applicant, message) VALUES (?, ?, ?)", (job_id, applicant, message))
        conn.commit()
        conn.close()

        return redirect(url_for('dashboard'))

    return render_template('apply.html', job_id=job_id)

@app.route('/update_application/<int:application_id>/<status>', methods=['POST'])
def update_application(application_id, status):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE applications SET status = ? WHERE id = ?", (status, application_id))
    conn.commit()
    conn.close()
    
    return redirect(url_for('dashboard'))

@app.route('/post_job', methods=['GET', 'POST'])
def post_job():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        posted_by = session['username']

        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO jobs (title, description, posted_by) VALUES (?, ?, ?)", 
                       (title, description, posted_by))
        conn.commit()
        conn.close()

        return redirect(url_for('dashboard'))

    return render_template('post_job.html')




@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
